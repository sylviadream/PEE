﻿<HTML><HEAD><TITLE>system desktop</TITLE>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<LINK href="style/Style.css" type=text/css rel=stylesheet>
<STYLE type=text/css>
BODY {
	MARGIN: 0px 0px; 
	BACKGROUND-COLOR: #ffffff;
}
</STYLE>
</HEAD>
<!--#include file="conn.asp"-->
<!--#include file="info/include/tools.asp"-->
<TD>&nbsp;</TD>
    <table width="800" border="0">
      <tr>
        <td width="160" height="125" align="center">
        </td>
        <td width="160" align="center"><p>&nbsp;</p>        </td>
        <td width="160" align="center">       
        </td>
        <td width="160" align="center"><p>&nbsp;</p>
        </td>
        <td width="160" align="center">
        </td>
      </tr>
      <tr>
        <td height="125" align="center"><p><a href='product/showproduct.php?mtype=1&stype=1'><img src="images/huopin.jpg" width="64" height="64" border="0"></a></p>
        <p><a href="product/showproduct.php?mtype=1&stype=1">clothes information</a></p></td>
        <td align="center"><img src="images/main_15.gif" width="84" height="63"></td>
        <td align="center"><p><a href="receipt_exchange/receipt_exchange.php"><img src="images/kucun2.gif" width="64" height="64" border="0"></a></p>
        <p><a href="receipt_exchange/receipt_exchange.php">Inventory allocation</a></p></td>


      </tr>
      <tr>
        <td height="125" align="center">
        </td>
        <td align="center">&nbsp;</td>
        <td align="center"><a href="basic/warehouse/warehouse_show.php"><img src="images/main_21.png" width="84" height="83" border="0"></a></td>
        <td align="center">&nbsp;</td>
        <td align="center"><p>&nbsp;</p>        
        </td>
      </tr>
      <tr>
        <td height="125" align="center"><p><a href="inquire_inout/inquire_inout_item.php"><img src="images/kucun4.gif" width="70" height="70" border="0"></a></p>
        <p><a href="inquire_inout/inquire_inout_item.php">Warehouse details</a></p></td>
        <td align="center"><img src="images/main_1.gif" width="84" height="63"></td>
        <td align="center"><p><a href="receipt_check/receipt_check.php"><img src="images/xiaoshou5.gif" width="64" height="64" border="0"></a></p>
        <p><a href="receipt_check/receipt_check.php">stock-taking</a></p></td>
        <td align="center"><p><img src="images/main_3b.gif" width="84" height="63"></p>        </td>
        <td align="center"><p><a href="inquire_inout/inquire_inout_receipt.php"><img src="images/xiaoshou2.gif" width="64" height="64" border="0"></a></p>
        <p><a href=inquire_inout/inquire_inout_receipt.php">Inbound and outbound query</a></p></td>
      </tr>
      <tr>
        <td height="125" align="center">
        </td>
        <td align="right">&nbsp;</td>
        <td align="center">      
        </td>
        <td>&nbsp;</td>
        <td align="center">
        </td>
      </tr>
    </table>
</BODY></HTML>
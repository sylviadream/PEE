<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
	include "../basic/include.php";
	include "../basic/database.php";

$date = $_POST[date];
$yewuyuan = $_POST[yewuyuan];
$type = $_POST[type];
$company = $_POST[company];
$warehouse = $_POST[warehouse];
$remark = $_POST[remark];
$itemstr = $_POST[item_str];

//echo "$yewuyuan||$date||$company||$warehouse||$type||$itemstr";die();

if($yewuyuan==''||$date==''||$company==''||$warehouse==''||$type==''||$itemstr=='' )//$id==''||
	$error='The submitted form is incorrect!';
else
{	
	$date2 = date("ymd");
	$id = $date2."00";
	
	if(mysql_query("select * from table_warehouse_$warehouse")==false)//Check if the target warehouse library table is healthy
		die("Warehouse $warehouse does not exist!");
		
	$query = "select * from test_receipt where id = '$id'";
	$result = mysql_query($query);
	$RS = mysql_fetch_array($result);
	
	while(!empty($RS)){
		if(($id = next_value($id))!="Overflow!"){//Get the available ID
			$query = "select * from test_receipt where id = '$id'";
			$result = mysql_query($query);
			$RS = mysql_fetch_array($result);
		}
		else{
			$error='Number overflow!';
			break;
		}	
	}
	
	if($error=='')//Insert inbound order
	{
		$query = "insert test_receipt values ('$id', '$date', '$yewuyuan', '$type', '$company', '$warehouse', '$remark', '$itemstr')";
		$result = mysql_query($query);
	}
	
	//Handling the goods list ——————
	$list = explode('|',$itemstr);//print_r($list);
	foreach($list as $str){
		$info = explode('+',$str);//print_r($info);
		$item_id = $info[0];
		$item_num = $info[1];
		$item_price = $info[2];
		
		$inout_id = $date2."00";
		$query = "select * from test_inout where id = '$inout_id'";
		$result = mysql_query($query);
		$RS = mysql_fetch_array($result);
		while(!empty($RS)){
			if(($inout_id = next_value($inout_id))!="Overflow!"){//Get the available ID
				$query = "select * from test_inout where id = '$inout_id'";
				$result = mysql_query($query);
				$RS = mysql_fetch_array($result);
			}
			else{
				$error='Number overflow!';
				break;
			}	
		}
		if($error=='')//Insert inbound record
		{
			$query = "insert test_inout values ('$inout_id', '$item_id', '$item_num', '$item_price', '$id', '$type')";
			$result = mysql_query($query);
		}
		
		$query = "select * from table_warehouse_$warehouse where id = '$item_id'";//Change the quantity of the corresponding item in the warehouse
		$result = mysql_query($query );
		$RS = mysql_fetch_array($result);
		if(empty($RS)){//If the item was not previously in the warehouse, insert the item; otherwise update the item
			$query = "insert table_warehouse_$warehouse values('$item_id' , $item_num )";//echo "<br>".$query."<br>";
			mysql_query($query);
		}
		else{
			$item_num += $RS[num];
			$query = "update table_warehouse_$warehouse set num = $item_num where id = '$item_id'";//echo "<br>".$query."<br>";
			mysql_query($query);
		}
	}

	mysql_close();
}

echo '<script language="javascript">';
echo 'var url;';

if($error=='')
{
	if($result == FALSE){
		echo "alert('Add failed!');";
		echo "var url = 'receipt_in.php';";
	}
	else{
		echo "alert('Added successfully!');\n";
		echo "var url = 'receipt_in.php';";
	}
}
else
{
	echo "alert('$error');";
	echo "var url = 'receipt_in.php';";
}

echo 'location.href=url;';
echo '</script>'
?>
﻿<?php
	session_start();
	include "../conn/conn.php";
    $sql = "select id,name from tb_admin";
	$result =  $result = $conn->query($sql);
	$i=0;	
?>
<link href="../css/style.css" rel="stylesheet" />
<?php
  include("../const.php");
   
  if ($authority[18]==0)
 {  
      echo "<script language='javascript'>alert('Sorry, you don't have permission to do this.！');history.back();</script>";
      exit;
  }
?>
<script >

function chkinput(form)
	{
	  if(form.adminname.value=="")
	   {
	     alert("please entre username!");
		 form.adminname.select();
		 return(false);
	   }
	
	   return(true);
	}

function chAll(name,flag)
{
 var len = document.getElementsByName(name).length;
 var check=flag;
 if(check==true)
 {
    for(var i=0; i < len; i++)
   {
      document.getElementsByName(name)[i].checked = true;
   }
 }
 else
 {
    for(var i=0; i < len; i++)
   {
      document.getElementsByName(name)[i].checked = false;
   }
  }
}
 
 </script>


<style type="text/css">
<!--
.STYLE1 {font-size: 18px}
.STYLE2 {font-size: 16px}
-->
</style>

<table width="853" border="1" cellpadding="0" cellspacing="0" class="big_td">
	<tr>
		<td width="46" height="33" background="../iages/list.jpg" id="list">&nbsp;</td>
	    <td width="841" background="../images/list.jpg" id="list">Operator setting</td>
	</tr>
</table>
<form name="form" method="post" action="saveadmin.php?flag=0" onSubmit="return chkinput(this)">
<table width="1104" border="0" cellpadding="0" cellspacing="0" bgcolor="#DEEBEF">
  <tr>
    <td height="50" colspan="2" rowspan="4" align="center" valign="middle" scope="col"><select name="left" size="20" multiple style="width:100px;"onchange="javascript:window.open('adminsetting.php?name='+ this.value, '_self');">
       <?php
	 	while($rows = mysql_fetch_row($result)){
		   if($rows[1]==$name)
		   {
		     echo "<option value='".$rows[1]."'style='background:#FFFF00' >".$rows[1]."</option>";
		   }
		   else
		
			echo "<option value='".$rows[1]."'>".$rows[1]."</option>";		
		}
	 ?>
    </select>
      <?php
		   $sql="select * from tb_admin where name='".$_GET[name]."'";
		   $result = $conn->query($sql);
		   $info= mysqli_fetch_array($result);
		   $auth=explode(",",$info[authority]);
		  
	 ?>
    <td width="827" height="49" align="left" valign="top" scope="col"><label>User name：
        <span class="STYLE1">
        <input name="adminname" type="text" value="<?php echo $info[name];?>" class="big_td" />
        </span></label><label>Password：
        <input type="password" name="pwd" />
        <a href="addadmin.php" target="_self"><img src="../images/adduser.jpg" alt="add User" width="30" height="30" border="3" /></a>New user<br />
     </label></td>
  </tr>
  <tr>
    <td height="5" align="left" valign="top" scope="col"><img src="../images/line.gif" width="600" height="4" /></td>
  </tr>
  <tr>
    <td height="10" align="left" valign="top" scope="col"><label><br />
    </label>
      <label></label></td>
  </tr>

  <tr>
    <td height="33" colspan="3" align="left" valign="middle">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     Start account or non?
      <select name="state">
         <option value="1"  <?php if($info[state]==1 ){ ?>selected="selected"<?php } ?>>start</option>
         <option value="0" <?php if($info[state]==0 ){?>selected="selected"<?php } ?>>stop</option>
		 <option value="2" >delete</option>
      </select>
      </td>
  </tr>
  <tr>
    <td height="34" colspan="3" align="center" valign="middle">
      <input type="submit" name="Submit" value="Submit" />
      <input name="button" type="button" onclick="javascript:window.open('adminsetting.php?name=<?php echo $name;?>', '_self')" value="Cancle" />   </td>
  </tr>
  <tr>
    <td height="67" colspan="3" align="center" valign="middle">&nbsp;</td>
  </tr>
</table>
</form>

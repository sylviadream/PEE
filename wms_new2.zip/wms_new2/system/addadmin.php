﻿<?php
	session_start();
	$name=$_GET[name];
	$i=0;
	include "../conn/conn.php";
    $sqlstr = "select id,name from tb_admin";
    $result = $conn->query($sqlstr);

?>
<link href="../css/style.css" rel="stylesheet" />
<script >


function chkinput(form)
	{
	  if(form.adminname.value=="")
	   {
	     alert("please entre username!");
		 form.adminname.select();
		 return(false);
	   }
	  
	
	
	  if(form.pwd.value=="")
	   {
	     alert("please entre password!");
		 form.pwd.select();
		 return(false);
	   }
	
	   return(true);
	}

 function Refresh() 
{ 

  var v=document.getElementsByTagName("input"); 
  for(var i=0;i<v.length;i++) 
 { 
    if(v[i].type=="text") 
    { 
      v[i].value=""; 
    } 
    if(v[i].type=="checkbox")
    {
        v[i].checked =false;  
    }
  } 
  
  
}

function chAll(name,flag)
{
 var len = document.getElementsByName(name).length;
 var check=flag;
 if(check==true)
 {
    for(var i=0; i < len; i++)
   {
      document.getElementsByName(name)[i].checked = true;
   }
 }
 else
 {
    for(var i=0; i < len; i++)
   {
      document.getElementsByName(name)[i].checked = false;
   }
  }
}
 
 </script>
<style type="text/css">
<!--
.STYLE1 {font-size: 18px}
.STYLE2 {font-size: 16px}
-->
</style>
<table width="853" border="1" cellpadding="0" cellspacing="0" class="big_td">
  <tr>
    <td width="46" height="33" background="../iages/list.jpg" id="list">&nbsp;</td>
    <td width="841" background="../images/list.jpg" id="list">New user</td>
  </tr>
</table>
<form name="form" method="post" action="saveadmin.php?flag=1" onSubmit="return chkinput(this)">
  <table width="800" border="0" cellpadding="0" cellspacing="0" bgcolor="#DEEBEF">
    <tr>
      <td height="255" colspan="2" rowspan="4" align="center" valign="middle" scope="col"><select name="left" size="20" multiple style="width:100px;"onchange="javascript:window.open('adminsetting.php?name='+ this.value, '_self');">
          <?php
	 	while($rows = mysql_fetch_row($result)){
		   if($rows[1]==$name)
		   {
		     echo "<option value='".$rows[1]."'style='background:#FFFF00' >".$rows[1]."</option>";
		   }
		   else
		
			echo "<option value='".$rows[1]."'>".$rows[1]."</option>";		
		}
	 ?>
        </select>
      <td width="827" height="49" align="center" valign="top" scope="col"><label>Username： <span class="STYLE1">
        <input name="adminname" type="text" class="big_td" />
        </span></label>
        <label>Password：
        <input type="password" name="pwd" />
        </label></td>
    </tr>
    <tr>
      <td height="5" align="left" valign="top" scope="col"><img src="../images/line.gif" width="600" height="4" /></td>
    </tr>
    

    <tr>
      <td height="33" colspan="3" align="left" valign="middle">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        start account or not?
        <select name="state">
          <option value="1" selected >start</option>
          <option value="0" >stop</option>
        </select>
    </td>
    </tr>
    <tr>
      <td height="34" colspan="3" align="center" valign="middle"><input type="submit" name="Submit" value="Submit" />
        <input name="button" type="button" onClick="Refresh()" value="Refresh" />      </td>
    </tr>
    <tr>
      <td height="67" colspan="3" align="center" valign="middle">&nbsp;</td>
    </tr>
  </table>
</form>

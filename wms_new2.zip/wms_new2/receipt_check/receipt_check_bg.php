<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include "../basic/include.php";
include "../basic/database.php";

$date = $_POST[date];
$yewuyuan = $_POST[yewuyuan];
$warehouse = $_POST[warehouse];
$remark = $_POST[remark];
$itemstr = $_POST[item_str];

//echo "$yewuyuan||$date||$warehouse||$itemstr";die();

if($yewuyuan==''||$date==''||$warehouse==''||$itemstr=='' )//$id==''||$company==''||$type==''
	$error='The submitted form is incorrect!';
else
{	
	$date2 = date("ymd");
	$id = $date2."00";
	
	if(mysql_query("select * from table_warehouse_$warehouse")==false)//Check if the target warehouse data table is healthy
		die("Warehouse $warehouse does not exist!");
		
	$query = "select * from test_check where id = '$id'";
	$result = mysql_query($query);
	$RS = mysql_fetch_array($result);
	
	while(!empty($RS)){
		if(($id = next_value($id))!="Overflow!"){//Get the available ID
			$query = "select * from test_check where id = '$id'";
			$result = mysql_query($query);
			$RS = mysql_fetch_array($result);
		}
		else{
			$error='Number overflow!';
			break;
		}	
	}
	
	if($error=='')//Insert inbound order
	{
		$query = "insert test_check values ('$id', '$date', '$yewuyuan', '$warehouse', '$remark', '$itemstr')";
		$result = mysql_query($query);
	}
	mysql_close();
}

echo '<script language="javascript">';
echo 'var url;';

if($error=='')
{
	if($result == FALSE){
		echo "alert('Add failed!');";
		echo "var url = 'receipt_check.php';";
	}
	else{
		echo "alert('Added successfully!');\n";
		echo "var url = 'receipt_check.php';";
	}
}
else
{
	echo "alert('$error');";
	echo "var url = 'receipt_check.php';";
}

echo 'location.href=url;';
echo '</script>'
?>
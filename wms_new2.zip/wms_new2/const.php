﻿<?php
   session_start();
   include("conn/conn.php");

   $info='0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1';
   $authority=explode(",",$info);
?>

﻿
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=uft-8" />
<title>Merald</title>
</head><frameset rows="63,*,32" cols="*" frameborder="no" border="0" framespacing="0">
  <frame src="top.php" name="topFrame" scrolling="No" noresize="noresize" id="topFrame" title="topFrame" />
  <frameset rows="*" cols="177,*" framespacing="0" frameborder="no" border="0">
    <frame src="menu.php" name='left' scrolling='yes' noresize='noresize' />
    <frame src="desk.php" name='right' scrolling='yes' noresize='noresize' />
  </frameset>
  <frame src="bottom.php" name="bottomFrame" scrolling="No" noresize="noresize" id="bottomFrame" title="bottomFrame" />
</frameset>
<noframes><body>
</body>
</noframes></html>

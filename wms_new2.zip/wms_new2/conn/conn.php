﻿

<?php
$host="localhost";
$user="root";
$password="19881208";
$database = "db_wms";
$conn = new mysqli($host, $user, $password, $database);


if($conn->connect_errno > 0){
    die('Unable to connect to database [' . $conn->connect_error . ']');
}

?>

<?php //����MySql����
	$con = mysql_connect("localhost","root","1234") or die("Unable to connect to Mysql Server");
	mysql_select_db("db_wms", $con) or die("Database selection failed");
	mysql_query("set names gb2312 ");
?>
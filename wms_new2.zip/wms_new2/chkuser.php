﻿<?php
include("conn/conn.php");
include("inc/func.php");

$username='hust';
//$username=$_POST[username];
$userpwd='112';
//$userpwd=$_POST[userpwd];
$lifeTime=10*3600;


class chkinput{
   var $name;
   var $pwd;

   function chkinput($x,$y){
       $this->name=$x;
     $this->pwd=$y;
    }

   function checkinput(){
     include("conn/conn.php");



       $sql="SELECT * FROM tb_admin where name='".$this->name."'";
       $result = $conn->query($sql);

       $info=mysqli_fetch_array($result);


     if($info==false){
          echo "<script language='javascript'>alert('This user does not exist！');history.back();</script>";
          exit;
       }
      else{
	      if($info[state]==0){
			   echo "<script language='javascript'>alert('The user has been frozen！');history.back();</script>";
               exit;
			}
          
          if($info[pwd]==$this->pwd)
            {  
			   session_start();
	           $_SESSION[username]=$info[name];
			   //session_register("producelist");
			  // $producelist="";
			  // session_register("quatity");
			   // $quatity="";
			    w_log($_POST[action],$_SESSION[username]);
               header("location:main.php");
               exit;
            }
          else {
             echo "<script language='javascript'>alert('Password entry error！');history.back();</script>";
             exit;
           }

      }    
   }
 }

    $obj=new chkinput(trim($username),trim($userpwd));
    $obj->checkinput();
?>
<?php
//ASD--
include("../const.php");
if ($authority[10]==0){  
	echo "<script language='javascript'>alert('Sorry, you don't have this permission!');history.back();</script>";
	exit;
}
//ASD--

	include "../basic/include.php";
	include "../basic/database.php";

	$warehouse = $_GET[warehouse];
		
	$query = "select * from table_warehouse order by name";//echo $query."<br>";
	$result_warehouse = mysql_query($query);
	
	$query = "select * from table_company order by name";
	$result_company = mysql_query($query);
	
	$query = "select * from tb_inout where type='Out of the library' order by name";
	$result_inout = mysql_query($query);
	
	if($warehouse=='')
		$warehouse='0000';
	$query = "select * from table_warehouse_$warehouse order by id asc";//die($query);
	$result_item = mysql_query($query);
	
	//mysql_close();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Stock transfer</title>
</head>
<style>
</style>
<script type="text/javascript" src="../js/Calendar3.js"></script>
<link rel="stylesheet" type="text/css" href="../css/iframe.css" media="screen" />
<script language="javascript">
var MAX = 10;
//Form check
function checkForm(){//Check the entire form input before submitting the form, no error if there is an error
	/*var element = document.getElementById('id');
	if(element.value==''){
		alert('The document number cannot be empty!');
		element.focus();
		return false;
	}*/
	element = document.getElementById('control_date');//Check date
	if(element.value==''||element.value=='Click to select the date'){
		alert('The date of the order cannot be empty!');
		element.focus();
		return false;
	}
	element = document.getElementById('yewuyuan');//Check the salesman
	if(element.value==''){
		alert('The salesman can\'t be empty!');
		element.focus();
		return false;
	}
	element = document.getElementById('item_str');//Check the goods
	if(element.value==''){
		alert('The goods in the form cannot be empty!');
		//element.focus();
		return false;
	}
	return true;
}
function chooseItem(button){//Select object
	var tr = button.parentNode.parentNode;
	document.getElementById('item_id').value = tr.cells[0].innerHTML;
	document.getElementById('item_name').value = tr.cells[1].innerHTML;
	document.getElementById('item_model').value = tr.cells[2].innerHTML;
	document.getElementById('item_unit').value = tr.cells[3].innerHTML;
	document.getElementById('item_num').focus();
}
function checkInput(){//Check: Whether the goods already exist; whether the unit price is standardized; whether the quantity is standardized, whether the maximum stock quantity is exceeded, etc.
	var table = document.getElementById('item_list');
	var length = table.rows.length;
	
	var item_id = document.getElementById('item_id').value;//Check the item ID
	if(item_id == 'Click to select the item'){//If no goods are selected
		alert('Please click to select the item!');
		return false;
	}
	var item_num = document.getElementById('item_num');//check the quantity
	if(item_num.value == ''){
		alert('The quantity of goods cannot be empty!');
		item_num.focus();
		return false;
	}

	
	var num = Number(item_num.value);
	var table2 = document.getElementById('storage');
	var length2 = table2.rows.length;
	var pos2 = 0;
	for(var i=0;i<length2;i++)
		if(table2.rows[i].cells[0].innerHTML == item_id)
			pos2 = i;
					
	if(pos2 == 0){
		alert('Error! Did not find the corresponding line!');
		return false;
	}
	else{
		var limit = Number(table2.rows[pos2].cells[4].innerHTML);
		if(num > limit){
			alert("Exceeding the outbound quota!");
			item_num.focus();
			return false;
		}
	}
	
	for(var i=1;i<length;i++)
		if(item_id == table.rows[i].firstChild.innerHTML){//If the selected item already exists
			if(confirm('The selected item already exists. If you continue adding it will overwrite the original information!')==true){
				if(editRow2()==true){
					updateStr();
					return false;//If the modification information is successful, no new line will be added, otherwise it will be processed by adding a new line.
				}
				else{
					return true;
				}
			}
			else return false;
		}
	//Other inspection items 
	
	
	return true;
}
function addRow(){//Add a row to the table
	var table = document.getElementById('item_list');
	var pos = table.rows.length;
	if(pos >= MAX+1){
		alert('The goods item has reached the maximum: MAX = ' + MAX);
		return false;
	}
	var tr = table.insertRow(pos);
	tr.align = 'center';
	var td0 = tr.insertCell(0);
	var td1 = tr.insertCell(1);
	var td2 = tr.insertCell(2);
	var td3 = tr.insertCell(3);
	var td4 = tr.insertCell(4);
	var td5 = tr.insertCell(5);
	var td6 = tr.insertCell(6);
//	var td7 = tr.insertCell(7);
//	var td8 = tr.insertCell(8);
	td0.innerHTML = document.getElementById('item_id').value;
	td1.innerHTML = document.getElementById('item_name').value;
	td2.innerHTML = document.getElementById('item_model').value;
	td3.innerHTML = document.getElementById('item_unit').value;
	td4.innerHTML = document.getElementById('item_num').value;
//	var price = new Number(document.getElementById('item_price').value);
//	td5.innerHTML = price.toFixed(2);
//	var price = document.getElementById('item_num').value*document.getElementById('item_price').value;
//	var price_str = price.toFixed(2);
//	td6.innerHTML = price_str;
	td5.innerHTML = '<a onclick="removeRow(this)">delete</a>';
	td6.innerHTML = '<a onclick="editRow(this)">modify</a>';
	updateStr();//Update the value of the hidden field
	//resetInput()//Restore the default edit box
	
}
function updateStr(){//Update the value of the hidden field
	var item_str = document.getElementById('item_str');
	var table = document.getElementById('item_list');
	var i,j;
	var str = '';
	var item_array = new Array(2);
	var item_info;
	var list_array = new Array(table.rows.length-1);
	for(i=1;i<table.rows.length;i++){
		item_array[0] = table.rows[i].cells[0].innerHTML;
		item_array[1] = table.rows[i].cells[4].innerHTML;
		//item_array[2] = table.rows[i].cells[5].innerHTML;
		item_info = item_array.join('+');
		list_array[i-1] = item_info;
	}
	str = list_array.join('|');
//	for(i=1;i<table.rows.length;i++){
//		str += '|' + table.rows[i].cells[0].innerHTML;
//		str += '&' + table.rows[i].cells[4].innerHTML;
//		str += '&' + table.rows[i].cells[5].innerHTML;
//	}
	item_str.value = str;
	alert(item_str.value);
	resetInput()
}
function removeRow(button){//Delete the line
	var tr = button.parentNode.parentNode;
	var table = tr.parentNode;
 	table.deleteRow(tr.rowIndex);
	updateStr();
}
function editRow(button){//Modify the row information, assign the value of the row to the edit field
	var tr = button.parentNode.parentNode;
	document.getElementById('item_id').value = tr.cells[0].innerHTML;
	document.getElementById('item_name').value = tr.cells[1].innerHTML;
	document.getElementById('item_model').value = tr.cells[2].innerHTML;
	document.getElementById('item_unit').value = tr.cells[3].innerHTML;
	document.getElementById('item_num').value = tr.cells[4].innerHTML;
//	document.getElementById('item_price').value = tr.cells[5].innerHTML;
}
function editRow2(){//Modify the row information to overwrite the original value with the value of the edit field
	var table = document.getElementById('item_list');
	var length = table.rows.length;
	var pos = 0;
	for(var i=0;i<length;i++)
		if(table.rows[i].cells[0].innerHTML == document.getElementById('item_id').value)
			pos = i;
			
	if(pos == 0){
		alert('Error! Did not find the corresponding line! Will add a new line!');
		return false;
	}
	else{
		var tr = table.rows[pos];
		tr.cells[0].innerHTML = document.getElementById('item_id').value
		tr.cells[1].innerHTML = document.getElementById('item_name').value
		tr.cells[2].innerHTML = document.getElementById('item_model').value
		tr.cells[3].innerHTML = document.getElementById('item_unit').value
		tr.cells[4].innerHTML = document.getElementById('item_num').value
//		var price = new Number(document.getElementById('item_price').value)
//		tr.cells[5].innerHTML = price.toFixed(2)
//		var price = document.getElementById('item_num').value * document.getElementById('item_price').value;
//		var price_str = price.toFixed(2);
//		tr.cells[6].innerHTML = price_str;
		return true;
	}
}
function resetInput(){//After submitting the input, set the input box character to the default (recommended in updateStr)
	document.getElementById('item_id').value = "Click to select the item";
	document.getElementById('item_name').value = "";
	document.getElementById('item_model').value = "";
	document.getElementById('item_unit').value = "";
	document.getElementById('item_num').value = "";
//	document.getElementById('item_price').value = "";
}
//function valueLimit(input){//Limit the price form of the input
//	var str = input.value;
//	var list = str.split('.');
//	if(list.length>2)
//		input.value = list[0] + '.' + list[1];
//	else if(list.length==2){
//		if(list[0]=='') list[0] = '0';
//		if(list[1].length>2) list[1] = list[1].substring(0,2);
//		input.value = list[0] + '.' + list[1];
//	}
//	else if(list[0].length>5){
//		input.value = list[0].substring(0,5);
//	}
//}
function numLimit(input){//Limit the number of outbounds to less than the quantity of goods in the warehouse
	var id = document.getElementById('item_id').value;
	var num = Number(input.value);
	var str = input.value;
	var table = document.getElementById('storage');
	var length = table.rows.length;
	var pos = 0;
	for(var i=0;i<length;i++)
		if(table.rows[i].cells[0].innerHTML == id)
			pos = i;
					
	if(pos == 0){
		//alert('Error! Did not find the corresponding line!');
		return false;
	}
	else{
		var limit = Number(table.rows[pos].cells[4].innerHTML);
		if(num > limit){
			input.value = str.substr(0,str.length-1);
			//alert("Exceeding the outbound quota!");
		}
	}
}
function showRight(){//Define the warehouse based on the inbound warehouse
	var left = document.getElementById('left');
	var right = document.getElementById('right');
	var y;
	if(left.selectedIndex != -1){
		for(var i=0;i<left.length;i++)
			if(i!=left.selectedIndex){
				y = document.createElement('option');
				y.text = left.options[i].text;
				y.value = left.options[i].value;
				right.add(y);
			}
	}
}
</script>
<body style="width:800px">
<form id="item_in" name="item_in" method="post" action="receipt_exchange_bg.php" onsubmit=" return checkForm()">
  <h3>Stock transfer</h3>
  <fieldset>
  <legend>Distributor information</legend>
  <label>Distributor senter</label>
  <select id="left" name="warehouse" onchange="location.href='receipt_exchange.php?warehouse='+this.value">
    <?php 
	while($RS = mysql_fetch_array($result_warehouse))
		if($warehouse == $RS[id])
			echo "<option value='$RS[id]' selected>$RS[name]</option>";
		else
			echo "<option value='$RS[id]'>$RS[name]</option>";
	?>
  </select>
  <label>Distributor Receive</label>
  <select id="right" name="warehouse2" >
    <script language="javascript">showRight()</script>
  </select>
  <a href="/wms/basic/warehouse/warehouse_show.php" target="_self"><img src="/wms/image/delete.gif" alt="仓库管理" width="25" height="19" border="0"/></a>
  </fieldset>
  <fieldset>
  <legend>Inventory list</legend>
  <table id="storage" width="500" border="1" cellspacing="0" cellpadding="5" style="font-size:12px; border:thin; border-color:#9999FF ">
    <tr align="center">
      <td>Item number</td>
      <td>Product name</td>
      <td>Specification model</td>
      <td>Unit</td>
      <td>Quantity</td>
      <td>Select</td>
    </tr>
    <?php
	while($RS = mysql_fetch_array($result_item)){
		echo "<tr align='center'>";
		echo "<td>$RS[id]</td>";	
		if(1){
			$query = "select * from tb_product where encode = '$RS[id]'";
			$result_iteminfo = mysql_query($query);
			$RS2 = mysql_fetch_array($result_iteminfo);
			echo "<td>$RS2[name]</td>";
			echo "<td>$RS2[size]</td>";
			echo "<td>$RS2[unit]</td>";
		}
		else{
			echo "<td></td>";
			echo "<td></td>";
			echo "<td></td>";
		}
		echo "<td>$RS[num]</td>";
		echo "<td><button type='button' onclick='chooseItem(this)'>select</button></td>";
		echo "</tr>";
	}
	?>
  </table>
  </fieldset>
  <fieldset>
  <legend>Form information</legend>
  <label>Document Number</label>
  <input id="id" name="id" type="text" onkeyup="value=value.replace(/[^\d]/g,'')" style="background-color:#CCCCCC" readonly/>
  <label>Order date</label>
  <input name="date" type="text" id="control_date" style="background-color:#CCCCCC" onclick="new Calendar().show(this);"  maxlength="10" readonly/>
  <p>&nbsp;</p>
  <label>Operateur</label>
  <input id="yewuyuan" name="yewuyuan" type="text" />
  <label>Remarks</label>
  <textarea name="remark" cols="13" rows="3" onkeyup="if(this.innerHTML.length>50) this.innerHTML=this.innerHTML.substr(0,50)"></textarea>
  </fieldset>
  <input name="item_str" id="item_str" style="display:none" hidden/>
  <!--Set to hidden domain-->
  <fieldset>
  <legend>Dialing list</legend>
  <table id="item_list" width="60%" border="1" cellspacing="0" cellpadding="5" style="font-size:12px; border:thin; border-color:#9999FF ">
    <tr align="center">
      <td>Item number</td>
      <td>Cloth name</td>
      <td>Specification model</td>
      <td>Unit</td>
      <td>Quantity</td>
      <!--<td>Unit price</td>-->
     <!-- <td>Subtotal</td>-->
      <td>Delete</td>
      <td>Modify</td>
    </tr>
  </table>
  </fieldset>
  <fieldset>
  <legend>Add cloth</legend>
  <label>Numbering</label>
  <input id="item_id" name="item_id" type="text" value="Click to select the item" size="10" style="background-color:#CCCCCC" readonly />
  <label>Name</label>
  <input id="item_name" name="item_name" type="text" size="5" style="background-color:#CCCCCC" readonly />
  <label>Specification</label>
  <input id="item_model" name="item_model" type="text" size="5" style="background-color:#CCCCCC" readonly />
  <label>Unit</label>
  <input id="item_unit" name="item_unit" type="text" size="5" style="background-color:#CCCCCC" readonly />
  <p>&nbsp;</p>
  <label>Quantity</label>
  <input name="item_num" type="text" id="item_num" onkeyup="value=value.replace(/[^\d]/g,'');numLimit(this)" maxlength="4" />
  <!--onchange="valueLimit(this)"-->
  <!--<label>Unit price</label>-->
  <!--<input name="item_price" type="text" id="item_price" onkeyup="value=value.replace(/[^.\d]/g,'');valueLimit(this)" maxlength="8" />-->
  <button type="button" onclick="if(checkInput()==true) addRow();">&nbsp;Add to&nbsp;</button>
  </fieldset>
  <fieldset>
  <legend>Other</legend>
  <button type="submit" style="margin-left:50px">&nbsp;submit Form&nbsp;</button>
  </fieldset>
</form>
<p><a href="../basic/company/company_show.php">Return to previous page</a></p>
</body>
</html>

﻿<?php


	include "../include.php";
	include "../database.php";
	
	$query="select * from table_measureunit";//echo $query."<br>";
	$result = mysql_query($query);

	mysql_close();	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Measureunit Management</title>
</head>
<script language="javascript">
//删除某个单位————
function removeUnit(){
	var x = document.getElementById("unit_list");
	if(x.selectedIndex != -1){
		var url = "../sql_delete_bg.php?db=measureunit&id="+x.options[x.selectedIndex].value;
		if(confirm("Are you sure to delete？")==true)
		location.href = url;
	}
	//alert("deleteOptionLeft() runing!");	
}
//删除某个单位————
//检查单位名称是否为空或在列表中是否存在，避免无谓的流量————
function checkForm(){
	var x = document.getElementById("unit_list");
	var y = document.getElementById("name");
	if(y.value == ''){
		alert("Measureunit can't be empty！");
		return false;
	}
	for(var i=0;i<x.length;i++)
		if(y.value == x.options[i].text){
			alert("Measureunit exist！");
			return false;
		}
	return true;
	//alert("deleteOptionLeft() runing!");	
}
//检查单位名称是否为空或在列表中是否存在，避免无谓的流量————
</script>
<body style="width:800px">
<h3>Measureunit Management</h3>
<form id="unitForm" name="unitForm" method="post" action="measureunit_add_bg.php" onsubmit="return checkForm()">
  <table border="1" cellpadding="5" cellspacing="0" bordercolor="#CC99FF">
    <tr valign="top" align="left">
      <td>Measureunit exist：</td>
      <td>
        <select id="unit_list" name="unit_list" size="10" ondblclick="removeUnit()">
          <?php while($RS=mysql_fetch_array($result)) echo "<option value='$RS[id]'>$RS[name]</option>"; ?>
        </select></td>
      <td>&nbsp;
        <input id="name" name="name" type="text" size="5" />
        <input name="add" type="submit" value="add" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input name="remove" type="button" id="remove" value="delete" onClick="removeUnit()"/></td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
</body>
</html>

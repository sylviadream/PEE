﻿<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
	include "../include.php";
	include "../database.php";

$string = $_POST[hidden];

if($string == "")
	$error='The submitted form is incorrect！';
else
{
	$str_array = explode("|",$string,3);
	$id = $str_array[0];
	$name = $str_array[1];
	$lowerclass = "|".$str_array[2];
	
	$query = "select * from table_itemclassify where id = '$id'";//echo $query."<br>";
	$result = mysql_query($query);
	$RS = mysql_fetch_array($result);
	
	if(empty($RS))
		$error = "ID is wrong, the target to be modified does not exist！";	
	else{
		$query = "update table_itemclassify set name='$name', lowerclass='$lowerclass' where id = '$id'";
		$result = mysql_query($query);
	}
	mysql_close();
}
?>
<script language="javascript">
var url;

<?php
if($error==''){
	if($result == FALSE){
		echo "alert('fail to edit!！');";
		echo "var url = 'itemclassify_show.php';";
	}
	else{
		echo "alert('Successfully modified! \\n number: $id\\n category name： $name\\n');\n";
		echo "var url = 'itemclassify_show.php';";
	}
}
else{
	echo "alert('$error');";
	echo "var url = 'itemclassify_show.php';";
}
?>

location.href=url;
</script>

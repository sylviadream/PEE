﻿<?php
  include("../conn/conn.php");
   $id=$_GET[id];
   $sql=mysql_query("select * from tb_inout where id='".$_GET[id]."'",$conn);
   $info=mysql_fetch_array($sql);
		  
?>
<title>Add out/in stockage type</title>
<link rel="stylesheet" type="text/css" href="css/font.css">
<style type="text/css">
<!--
.style5 {
	color: #000000;
	font-weight: bold;
}
.style6 {color: #000000}
.style7 {color: #990000}
.style1 {color: #FFFFFF}
.STYLE9 {color: #FFFFFF; font-size: 18px; }
.STYLE10 {font-size: 10px}
-->
</style>
<script language="javascript">
function showhide(value){
 var flag=value;;
 if (flag=="In stockage"){
  content.style.display="";
 }else{
  content.style.display="none";
 }
}
</script> 
<body topmargin="0" leftmargin="0" bottommargin="0" class="scrollbar">
  
<table width="600" border="1" align="center" cellpadding="0" cellspacing="30" bordercolor="#33FFCC">
  <tr>
    <td height="20" align="center" bgcolor="#3399FF"><span class="STYLE9">Clthes out/in stockage type set</span>Type set</td>
  </tr>
  <tr>
    <td align="center"><form name="form1" method="post" action="savenewinout.php?id=<?php echo $info[id];?>">
      <label>Type
      <select name="type" onChange="showhide(this.value);">
        <option value="In stockage" <?php if($info[type]==In stockage){ ?>selected="selected"<?php } ?>>In stockage</option>
        <option value="Out stockage"<?php if($info[type]==Out stockage){ ?>selected="selected"<?php } ?>>Out stockage</option>
      </select>
      </label>
        <label>Name
        <input type="text" name="name"value="<?php echo $info[name];?>" readOnly="true"/>
        </label>
        <p>
		<div id="content">
          <label>If participate in cost accounting
          <select name="cost">
            <option value="1"<?php if($info[cost]==1){ ?>selected="selected"<?php } ?>>Yes</option>
            <option value="0" <?php if($info[cost]==0){ ?>selected="selected"<?php } ?>>No</option>
          </select>
          </label>
		 </div>
        </p>
        <p>
          <label>
          <input type="submit" name="Submit" value="Save"> 
          </label>
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <label>
          <input type="button" name="button"onClick="javascript:window.open('inoutsetting.php','_self')" value="退出">
          </label>
        </p>
    </form>
    </td>
  </tr>
</table>
</body>
</html>

﻿<meta http-equiv="Content-Type" content="text/html; charset=utf-8 />
<?php
	include "../include.php";
	include "../database.php";
	
$id = $_POST["id"];
$name = $_POST["name"];
$fuzeren = $_POST["fuzeren"];
$phone = $_POST["phone"];
$address = $_POST["address"];
$remark = $_POST["remark"];

if($name=='')//||$fuzeren==''||$phone==''||$address==''||$remark==''
	$error='erreur of submit！';
else
{	
	$query = "select * from table_warehouse where id = '$id'";
	$result = mysql_query($query);
	$RS = mysql_fetch_array($result);
	
	if(empty($RS))
		$error='erreur ID！';
	else{
		$query = "select * from table_warehouse where name = '$name'";
		$result = mysql_query($query);
		$RS = mysql_fetch_array($result);
		if(!empty($RS)&&($RS['name']!=$name))
			$error='Duplicate distributor name！';
	}
	
	if($error=='')
	{
		$query = "update table_warehouse set name='$name',fuzeren='$fuzeren',phone='$phone',address='$address',remark='$remark' where id = '$id'";
		$result = mysql_query($query);
	}
	mysql_close();
}

if($error=='')
{
	if($result == FALSE){
		echo "alert('Failed to modify the distributor information! Return to the warehouse modification page!');";
		echo "var url = 'warehouse_modify.php?id=".$id."';";
	}
	else{
		echo "alert('Modify the distributor information successfully! Return to the distributor management interface! \\n number: $id\\n distributor name: $name\\n person in charge: $fuzeren\\n warehouse phone: $phone\\n distributor address:$address\\n remark： $remark');\n";
		echo "var url = 'warehouse_show.php';";
	}
}
else
{
	echo "alert('$error Return to the distributor add page！');";
	echo "var url = 'warehouse_modify.php?id=".$id."';";
}

?>

</script>






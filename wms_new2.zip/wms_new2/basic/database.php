﻿



<?php //����MySql����
	$con = mysql_connect("localhost","root","19881208") or die("cant conneted to sql");
	mysql_select_db("db_wms", $con) or die("");
	mysql_query("set names gb2312 ");
?>







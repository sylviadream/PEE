﻿<?php

	include "../basic/include.php";
	include "../basic/database.php";
	
	$query = "select count(*) as num from tb_product where 1";//echo $query."<br>";die();
	$result = mysql_query($query) or die("Invalid query: " . mysql_error());
	$RS = mysql_fetch_array($result);
	$num = $RS[num];
	
	$query = "select * from tb_product where 1 order by encode";//echo $query."<br>";die();
	$result_product = mysql_query($query);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Stock query-all clothes</title>
</head>
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
-->
</style>
<script type="text/javascript" src="../js/Calendar3.js"></script>
<script type="text/javascript" src="../js/TableSort_mains.js"></script>
<script language="javascript">
function gotoURL(target){
	var id = target.innerHTML;
	var url = "inquire_storage_item.php?itemid="+id;
	//location.href = url;
	window.open(url,'_blank','directorys=no,toolbar=no,status=no,menubar=no,scrollbars=yes,resizable=no,width=640,height=480,top=176,left=161');
}
function gotoURL2(target){
	var value = target.value;
	var url = "inquire_storage_allitem.php?option="+value;
	location.href = url;
}
</script>
<body style="width:800px; font-size:14px">
<div>
  <h3>Stock query-all clothes</h3>
  <p>total <?php echo $num; ?> item record</p>
  <div style="float:left">Click on the item number to see inventory details for that item</div>
  <div style="float:right">filtrate：
    <select name="filter" onchange="gotoURL2(this)">
      <option value="0" <?php if($_GET[option]==0) echo 'selected';?>>All</option>
      <option value="1" <?php if($_GET[option]==1) echo 'selected';?>>normal</option>
      <option value="2" <?php if($_GET[option]==2) echo 'selected';?>>exceed the maximum</option>
      <option value="3" <?php if($_GET[option]==3) echo 'selected';?>>below lower limit</option>
    </select>
  </div>
  <table id="table_storage" width="100%" border="1" cellspacing="0" cellpadding="5" bordercolor="#9999FF">
    <thead style="color: #330066">
      <tr align="center" bordercolor="#9999FF">
        <td onclick="SortTable('table_storage',0,'string')" style="cursor:pointer">Item number</td>
        <td onclick="SortTable('table_storage',1,'string')" style="cursor:pointer">Item name</td>
        <td onclick="SortTable('table_storage',2,'string')" style="cursor:pointer">model</td>
        <td onclick="SortTable('table_storage',3,'string')" style="cursor:pointer">unit</td>
        <td onclick="SortTable('table_storage',4,'int')" style="cursor:pointer">Upper limit of the stock</td>
        <td onclick="SortTable('table_storage',5,'int')" style="cursor:pointer">Inventory floor</td>
        <td onclick="SortTable('table_storage',6,'int')" style="cursor:pointer">stock</td>
        <td onclick="SortTable('table_storage',7,'string')" style="cursor:pointer">warning information</td>
      </tr>
    </thead>
    <tbody>
      <?php
	while($RS = mysql_fetch_array($result_product))
	{
		$sum = 0;
		$query = "select id from table_warehouse order by id";//echo $query."<br>";
		$result_warehouse = mysql_query($query);//获取仓库列表
		while($RS2 = mysql_fetch_array($result_warehouse)){
			$query = "select num from table_warehouse_$RS2[id] where id = '$RS[encode]'";//echo $query."<br>";
			$result_num = mysql_query($query);
			$RS3 = mysql_fetch_array($result_num);
			$sum += $RS3[num];
		}
		if($sum > $RS[upperlimit]){
			$string = "Upper limit of the stock";
			$color = 'red';
		}
		else if($sum < $RS[lowerlimit]){
			$string = "Inventory floor";
			$color = 'gray';
		}
		else{
			$string = "normal";
		 	$color = 'green';
		}
		$option = $_GET[option];
		if($option==0 || ($option==1&&$string=="normal") || ($option==2&&$string=="Upper limit of the stock") || ($option==3&&$string=="Inventory floor")){		
			echo "<tr align='center' bordercolor='#9999FF'>";
			echo "<td customvalue='$RS[encode]'><a href='inquire_storage_item.php?itemid=$RS[encode]'>$RS[encode]</a></td>\n";
			echo "<td>$RS[name]</td>\n";
			echo "<td>$RS[size]</td>\n";
			echo "<td>$RS[unit]</td>\n";
			echo "<td>$RS[upperlimit]</td>\n";
			echo "<td>$RS[lowerlimit]</td>\n";
			echo "<td>$sum</td>\n";
			echo "<td style='color:$color'>$string</td>\n";
			echo "</tr>";
		}
	}
?>
    </tbody>
  </table>
  <p>
    <input name="" type="button" value="export to WORD" onclick=" AllAreaWord()"/>
    <input name="" type="button" value="export to EXCEL" onclick="AutomateExcel()"/>
  </p>
<script language="javascript">
function AllAreaWord() 
{
	if(document.all("table_storage").rows.length==0){
		alert("no content to export！");
		return;
	}
	try{
		var oWD = new ActiveXObject("Word.Application"); 
	}
	catch(e){
		alert("unable to invoke office object，Make sure your machine has Office installed and that the system's site name has been added to IE's list of trusted sites！");
		return;
	}
	var oDC = oWD.Documents.Add("",0,1); 
	var oRange =oDC.Range(0,1); 
	var sel = document.body.createTextRange(); 
	sel.moveToElementText(table_storage); //tab 为导出数据所在的表格ID
	sel.select(); 
	sel.execCommand("Copy"); 
	oRange.Paste(); 
	oWD.Application.Visible = true; 
}

function AutomateExcel(){	
	try{
		var appExcel = new ActiveXObject( "Excel.Application" ); 
	}
	catch(e){
	  alert("unable to invoke office object，Make sure your machine has Office installed and that the system's site name has been added to IE's list of trusted sites！");
	  return;
	}
	var elTable = document.getElementById("table_storage"); //outtable 为导出数据所在的表格ID；
	var oRangeRef = document.body.createTextRange(); 
	
	oRangeRef.moveToElementText( elTable ); 
	oRangeRef.execCommand( "Copy" );
	
	appExcel.Visible = true; 
	appExcel.Workbooks.Add().Worksheets.Item(1).Paste(); 
	appExcel = null;
}
function selectitem(){//选择对象
	//var url = 'item_choose.php';
	var url = '../../wms/product/showproduct.php?stype=1&mtype=1';
	window.open(url,'_blank','directorys=no,toolbar=no,status=no,menubar=no,scrollbars=yes,resizable=no,width=853,height=470,top=176,left=161');
}
</script>
  <p>
  <div>other query way ：</div>
  <div> query by item ：
    <input id="item_id" name="item_id" type="text"  style="background-color:#CCCCCC" value="Click to select the item" onclick="selectitem()"/>
    <button type="button" onclick="if(document.getElementById('item_id').value!='Click to select the item'){url='inquire_storage_item.php?itemid='+document.getElementById('item_id').value;window.open(url,'_self');}">&nbsp;Check&nbsp;</button>
    <input id="item_name" name="item_name" type="text" size="5" style="background-color:#CCCCCC; visibility:hidden"/>
    <input id="item_model" name="item_model" type="text" size="5" style="background-color:#CCCCCC; visibility:hidden"/>
    <input id="item_unit" name="item_unit" type="text" size="5" style="background-color:#CCCCCC; visibility:hidden"/>
  </div>
  <div> query by distributor：
    <select id="warehouse" name="warehouse" onchange="if(this.value!='none'){url='inquire_storage_warehouse.php?warehouse='+this.value;window.open(url,'_self')}">
      <option value='none'>-Please select-</option>
      <?php 
	$query = "select * from table_warehouse order by name";//echo $query."<br>";
	$result_warehouse = mysql_query($query);//获取仓库列表
	
	while($RS = mysql_fetch_array($result_warehouse))
		echo "<option value='$RS[id]'>$RS[name]</option>";
	?>
    </select>
  </div>
  </p>
</div>
</div>
</body>
</html>

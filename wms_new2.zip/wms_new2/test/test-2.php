<SCRIPT LANGUAGE="javascript">
<!--
function AllAreaWord() 
{
	if(document.all("table_storage").rows.length==0){
		alert("No content to import！");
		return;
	}
	try{
		var oWD = new ActiveXObject("Word.Application"); 
	}
	catch(e){
		alert("Unable to call the Office object, make sure that your machine has Office installed and has added the system's site name to IE's list of trusted sites!");
		return;
	}
	var oDC = oWD.Documents.Add("",0,1); 
	var oRange =oDC.Range(0,1); 
	var sel = document.body.createTextRange(); 
	sel.moveToElementText(table_storage); //tab 为导Outbound 数据所在的表格ID
	sel.select(); 
	sel.execCommand("Copy"); 
	oRange.Paste(); 
	oWD.Application.Visible = true; 
}
function AutomateExcel(){	
	try{
		var appExcel = new ActiveXObject( "Excel.Application" ); 
	}
	catch(e){
	  alert("Unable to call the Office object, make sure that your machine has Office installed and has added the system's site name to IE's list of trusted sites!");
	  return;
	}
	var elTable = document.getElementById("table_storage"); //outtable 为导Outbound 数据所在的表格ID；
	var oRangeRef = document.body.createTextRange(); 
	
	oRangeRef.moveToElementText( elTable ); 
	oRangeRef.execCommand( "Copy" );
	
	appExcel.Visible = true; 
	appExcel.Workbooks.Add().Worksheets.Item(1).Paste(); 
	appExcel = null;
}
//-->
</SCRIPT>

<input type="button" name="tab" onClick="AutomateExcel();" value="export to excel" class="notPrint">
<table border="1" cellpadding="0" cellspacing="0" id=outtable>
  <tr height="28">
    <td width="27" height="86" rowspan="4" bgcolor="#ffffcc">Serial number</td>
    <td width="111" rowspan="4" bgcolor="#ffffcc"><div align="center">Service outlet</div></td>
    <td width="402" colspan="7" bgcolor="#ffffcc"><div align="center">Customer satisfaction</div></td>
  </tr>
  <tr height="19">
    <td width="100" height="39" colspan="3" rowspan="2" bgcolor="#ffffcc"><div align="center">Number of samples</div></td>
    <td width="218" colspan="3" rowspan="2" bgcolor="#ffffcc">The overall evaluation of the event for this service outlet, out of 10 points (average score)</td>
    <td width="84" rowspan="3" bgcolor="#ffffcc"><div align="center">Quarterly average</div></td>
  </tr>
  <tr height="20"> </tr>
  <tr height="19">
    <td width="29" height="19" bgcolor="#ffffcc"><div align="center">April</div></td>
    <td width="29" bgcolor="#ffffcc"><div align="center">May</div></td>
    <td width="42" bgcolor="#ffffcc"><div align="center">total</div></td>
    <td width="68" bgcolor="#ffffcc"><div align="center">April</div></td>
    <td width="68" bgcolor="#ffffcc"><div align="center">May</div></td>
    <td width="82" bgcolor="#ffffcc"><div align="center">total</div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td bgcolor="#ffffcc">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td bgcolor="#ffffcc">&nbsp;</td>
    <td bgcolor="#ffffcc">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td bgcolor="#ffffcc">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td bgcolor="#ffffcc">&nbsp;</td>
    <td bgcolor="#ffffcc">&nbsp;</td>
  </tr>
</table>



--------------------------------------------------------------------------------
